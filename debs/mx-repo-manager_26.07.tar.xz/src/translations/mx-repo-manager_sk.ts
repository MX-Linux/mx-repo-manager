<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="sk">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="168"/>
        <source>Authentication Canceled</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="169"/>
        <source>Authentication was canceled. No changes were applied.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="171"/>
        <source>Administrator Access Required</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="172"/>
        <source>This operation requires administrator privileges, but the helper could not be started correctly. No changes were applied.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="17"/>
        <location filename="../src/mainwindow.cpp" line="66"/>
        <source>MX Repo Manager</source>
        <translation>MX Repo Manager</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="32"/>
        <location filename="../src/mainwindow.cpp" line="863"/>
        <source>Select the APT repository that you want to use:</source>
        <translation>Vyberte APT repozitár, ktorý chcete používať: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="59"/>
        <source>MX repos</source>
        <translation>Repozitáre MX</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="84"/>
        <source>Select fastest MX repo for me</source>
        <translation>Vybrať najrýchlejší repozitár MX</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="110"/>
        <source>search</source>
        <translation>hľadať</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="168"/>
        <source>Debian repos</source>
        <translation>Repozitáre Debian </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="180"/>
        <source>Select fastest Debian repo for me</source>
        <translation>Vybrať najrýchlejší repozitár Debian</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="229"/>
        <source>Individual sources</source>
        <translation>Jednotlivé zdroje</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="248"/>
        <source>Restore original APT sources</source>
        <translation>Obnoviť pôvodné zdroje APT</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="329"/>
        <source>Display help </source>
        <translation>Zobraziť nápovedu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="332"/>
        <source>Help</source>
        <translation>Pomoc</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="338"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="383"/>
        <source>About this application</source>
        <translation>O tejto aplikácii</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="386"/>
        <source>About...</source>
        <translation>O Programe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="392"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="408"/>
        <source>Quit application</source>
        <translation>Zatvoriť aplikáciu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="411"/>
        <source>Close</source>
        <translation>Zavrieť</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="417"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="436"/>
        <source>Apply</source>
        <translation>Použiť</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="196"/>
        <location filename="../src/mainwindow.cpp" line="665"/>
        <location filename="../src/mainwindow.cpp" line="1083"/>
        <source>Success</source>
        <translation>Úspech</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="197"/>
        <location filename="../src/mainwindow.cpp" line="666"/>
        <location filename="../src/mainwindow.cpp" line="1087"/>
        <source>Your new selection will take effect the next time sources are updated.</source>
        <translation>Zmeny sa prejavia pri najbližšej aktualizácií.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="199"/>
        <source>No Changes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="200"/>
        <source>The selected repository is already configured.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="407"/>
        <source>Lists</source>
        <translation>Zoznamy</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="407"/>
        <source>Sources (checked sources are enabled)</source>
        <translation>Zdroje (zaškrtnuté zdroje sa používajú)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="668"/>
        <location filename="../src/mainwindow.cpp" line="904"/>
        <location filename="../src/mainwindow.cpp" line="933"/>
        <location filename="../src/mainwindow.cpp" line="946"/>
        <location filename="../src/mainwindow.cpp" line="954"/>
        <location filename="../src/mainwindow.cpp" line="975"/>
        <location filename="../src/mainwindow.cpp" line="988"/>
        <location filename="../src/mainwindow.cpp" line="995"/>
        <location filename="../src/mainwindow.cpp" line="1009"/>
        <location filename="../src/mainwindow.cpp" line="1017"/>
        <location filename="../src/mainwindow.cpp" line="1090"/>
        <source>Error</source>
        <translation>Chyba</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="668"/>
        <source>Could not change the repo.</source>
        <translation>Repozitár na nepodarilo zmeniť.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="693"/>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="699"/>
        <source>Please wait...</source>
        <translation>Čakajte prosím...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="787"/>
        <source>About %1</source>
        <translation>Okolo %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="788"/>
        <source>Version: </source>
        <translation>Verzia:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="790"/>
        <source>Program for choosing the default APT repository</source>
        <translation>Program pre výber predvolených repozitárov.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="792"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="793"/>
        <source>%1 License</source>
        <translation>%1 Licencia</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="807"/>
        <source>%1 Help</source>
        <translation>%1 Pomoc</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="824"/>
        <source>Warning</source>
        <translation>Upozornenie</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="825"/>
        <source>You have selected MX Test Repo. It&apos;s not recommended to leave it enabled or to upgrade all the packages from it.</source>
        <translation>Vybrali ste MX Test Repo. Neodporúčame ho nechať vybraný alebo aktualizovať z neho balíky.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="828"/>
        <source>A safer option is to install packages individually with MX Package Installer.</source>
        <translation>Bezpečnejšia možnosť je inštalovať balíky individuálne cez MX Inštalátor balíkov.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="865"/>
        <source>Select the APT repository and sources that you want to use:</source>
        <translation>Vyberte APT repozitár a zdroje, ktoré chcete používať: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="933"/>
        <source>netselect-apt could not detect fastest repo.</source>
        <translation>Príkaz netselect-apt nenašiel najrýchlejší repozitár.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1090"/>
        <source>Could not restore the original APT source files.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="904"/>
        <location filename="../src/mainwindow.cpp" line="946"/>
        <location filename="../src/mainwindow.cpp" line="954"/>
        <location filename="../src/mainwindow.cpp" line="975"/>
        <source>Could not detect fastest repo.</source>
        <translation>Najrýchlejší repozitár sa nenašiel.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="76"/>
        <source>Updating package sources...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="988"/>
        <source>Can&apos;t figure out if this app is running on antiX or MX</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="996"/>
        <source>MX version not detected or out of range: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1009"/>
        <source>Could not download original APT files.</source>
        <translation>Nemôžem stiahnuť originálne APT súbory.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1017"/>
        <source>Could not unzip downloaded file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1061"/>
        <source>Enabling AHS</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1061"/>
        <source>Do you use AHS (Advanced Hardware Stack) repo?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1084"/>
        <source>Original APT sources have been restored to the release status. User added source files in /etc/apt/sources.list.d/ have not been touched.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="52"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="75"/>
        <source>License</source>
        <translation>Licencia</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="76"/>
        <location filename="../src/about.cpp" line="86"/>
        <source>Changelog</source>
        <translation>História zmien</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="77"/>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="98"/>
        <source>Could not load changelog.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="32"/>
        <location filename="../src/about.cpp" line="101"/>
        <source>&amp;Close</source>
        <translation>&amp;Zatvoriť</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="83"/>
        <location filename="../src/main.cpp" line="92"/>
        <source>Error</source>
        <translation>Chyba</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="84"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="93"/>
        <source>You must run this program with admin access.</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>