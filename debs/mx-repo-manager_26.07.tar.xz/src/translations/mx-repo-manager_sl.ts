<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="sl">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="168"/>
        <source>Authentication Canceled</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="169"/>
        <source>Authentication was canceled. No changes were applied.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="171"/>
        <source>Administrator Access Required</source>
        <translation>Zahtevan je skrbniški dostop</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="172"/>
        <source>This operation requires administrator privileges, but the helper could not be started correctly. No changes were applied.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="17"/>
        <location filename="../src/mainwindow.cpp" line="66"/>
        <source>MX Repo Manager</source>
        <translation>MX upravljalnik skladišč</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="32"/>
        <location filename="../src/mainwindow.cpp" line="863"/>
        <source>Select the APT repository that you want to use:</source>
        <translation>Izberite APT skladišče, ki ga želite uporabljati:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="59"/>
        <source>MX repos</source>
        <translation>MX skladišča</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="84"/>
        <source>Select fastest MX repo for me</source>
        <translation>Izberi najhitrejše MX skladišče</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="110"/>
        <source>search</source>
        <translation>iskanje</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="168"/>
        <source>Debian repos</source>
        <translation>Debian skladišča</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="180"/>
        <source>Select fastest Debian repo for me</source>
        <translation>Izberi najhitrejše Debian skladišče</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="229"/>
        <source>Individual sources</source>
        <translation>Lastni viri</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="248"/>
        <source>Restore original APT sources</source>
        <translation>Obnovi izvirne APT vire</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="329"/>
        <source>Display help </source>
        <translation>Prikaži pomoč</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="332"/>
        <source>Help</source>
        <translation>Pomoč</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="338"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="383"/>
        <source>About this application</source>
        <translation>O tem programu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="386"/>
        <source>About...</source>
        <translation>O programu...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="392"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="408"/>
        <source>Quit application</source>
        <translation>Zapri aplikacijo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="411"/>
        <source>Close</source>
        <translation>Zapri</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="417"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="436"/>
        <source>Apply</source>
        <translation>Uveljavi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="196"/>
        <location filename="../src/mainwindow.cpp" line="665"/>
        <location filename="../src/mainwindow.cpp" line="1083"/>
        <source>Success</source>
        <translation>Operacija je uspela</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="197"/>
        <location filename="../src/mainwindow.cpp" line="666"/>
        <location filename="../src/mainwindow.cpp" line="1087"/>
        <source>Your new selection will take effect the next time sources are updated.</source>
        <translation>Vaša nova izbira bo postala aktivna, ko bodo viri naslednjič posodobljeni.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="199"/>
        <source>No Changes</source>
        <translation>Brez sprememb</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="200"/>
        <source>The selected repository is already configured.</source>
        <translation>Izbrano skladišče je že nastavljeno.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="407"/>
        <source>Lists</source>
        <translation>Seznami</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="407"/>
        <source>Sources (checked sources are enabled)</source>
        <translation>Viri (označeni viri so vklopljeni)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="668"/>
        <location filename="../src/mainwindow.cpp" line="904"/>
        <location filename="../src/mainwindow.cpp" line="933"/>
        <location filename="../src/mainwindow.cpp" line="946"/>
        <location filename="../src/mainwindow.cpp" line="954"/>
        <location filename="../src/mainwindow.cpp" line="975"/>
        <location filename="../src/mainwindow.cpp" line="988"/>
        <location filename="../src/mainwindow.cpp" line="995"/>
        <location filename="../src/mainwindow.cpp" line="1009"/>
        <location filename="../src/mainwindow.cpp" line="1017"/>
        <location filename="../src/mainwindow.cpp" line="1090"/>
        <source>Error</source>
        <translation>Napaka</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="668"/>
        <source>Could not change the repo.</source>
        <translation>Nisem mogel zamenjati skladišča.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="693"/>
        <source>Cancel</source>
        <translation>Prekliči</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="699"/>
        <source>Please wait...</source>
        <translation>Prosimo, počakajt...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="787"/>
        <source>About %1</source>
        <translation>O %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="788"/>
        <source>Version: </source>
        <translation>Različica:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="790"/>
        <source>Program for choosing the default APT repository</source>
        <translation>Program za določitev privzetega APT skladišča</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="792"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Avtorska zaščita (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="793"/>
        <source>%1 License</source>
        <translation>%1 licenca</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="807"/>
        <source>%1 Help</source>
        <translation>%1 pomoč</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="824"/>
        <source>Warning</source>
        <translation>Opozorilo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="825"/>
        <source>You have selected MX Test Repo. It&apos;s not recommended to leave it enabled or to upgrade all the packages from it.</source>
        <translation>Izbrali ste MX testno skladišče. Njegova uporaba ni priporočljiva za nameščanje ali nadradnje.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="828"/>
        <source>A safer option is to install packages individually with MX Package Installer.</source>
        <translation>Bolj varna možnost je nameščanje paketov s pomočjo MX namestilnik paketov</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="865"/>
        <source>Select the APT repository and sources that you want to use:</source>
        <translation>Izberite APT skladišče in vire, ki jih želite uporabljati:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="933"/>
        <source>netselect-apt could not detect fastest repo.</source>
        <translation>netselect-apt ni mogel najti najhitrejšega skladišča.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1090"/>
        <source>Could not restore the original APT source files.</source>
        <translation>Nisem mogel obnoviti originalnih datotek APT virov.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="904"/>
        <location filename="../src/mainwindow.cpp" line="946"/>
        <location filename="../src/mainwindow.cpp" line="954"/>
        <location filename="../src/mainwindow.cpp" line="975"/>
        <source>Could not detect fastest repo.</source>
        <translation>Najhitrejšega skladišča ni bilo mogoče odkriti</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="76"/>
        <source>Updating package sources...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="988"/>
        <source>Can&apos;t figure out if this app is running on antiX or MX</source>
        <translation>Ni mogoče ugotoviti ali ta aplikacija teče na antiX ali MX</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="996"/>
        <source>MX version not detected or out of range: </source>
        <translation>MX različica ni zaznana ali je izven obsega:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1009"/>
        <source>Could not download original APT files.</source>
        <translation>Izvnirnih APT datotek ni bilo mogoče prenesti.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1017"/>
        <source>Could not unzip downloaded file.</source>
        <translation>Prenešen datoteke ni bilo mogoče razširiti.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1061"/>
        <source>Enabling AHS</source>
        <translation>Vklop AHS</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1061"/>
        <source>Do you use AHS (Advanced Hardware Stack) repo?</source>
        <translation>Uporabljate AHS (Advanced Hardware Stack) skladišče?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1084"/>
        <source>Original APT sources have been restored to the release status. User added source files in /etc/apt/sources.list.d/ have not been touched.</source>
        <translation>Izvirni APT viri so bili obnovljeni na stanje ob izdaji. Izvorne datoteke, ki jih je uporabnik dodal v /etc/apt/sources.list.d/, niso bile spremenjene.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="52"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="75"/>
        <source>License</source>
        <translation>Licenca</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="76"/>
        <location filename="../src/about.cpp" line="86"/>
        <source>Changelog</source>
        <translation>Dnevnik sprememb</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="77"/>
        <source>Cancel</source>
        <translation>Prekliči</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="98"/>
        <source>Could not load changelog.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="32"/>
        <location filename="../src/about.cpp" line="101"/>
        <source>&amp;Close</source>
        <translation>&amp;Zapri</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="83"/>
        <location filename="../src/main.cpp" line="92"/>
        <source>Error</source>
        <translation>Napaka</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="84"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Prijevljeni ste kot korenski uporabnik. Izpišite se in se ponovno prijavite kot običajen uporabnik, če želite uporabljati ta program.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="93"/>
        <source>You must run this program with admin access.</source>
        <translation>Ta program je potrebno zagnati s skrbniškim dostopom</translation>
    </message>
</context>
</TS>