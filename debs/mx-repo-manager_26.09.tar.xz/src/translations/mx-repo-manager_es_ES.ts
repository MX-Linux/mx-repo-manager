<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="es_ES">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="185"/>
        <source>Authentication Canceled</source>
        <translation>Autenticación cancelada</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="186"/>
        <source>Authentication was canceled. No changes were applied.</source>
        <translation>La autentificación fue cancelada. No se realizaron cambios.</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="188"/>
        <source>Administrator Access Required</source>
        <translation>Se requiere acceso de administrador</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="189"/>
        <source>This operation requires administrator privileges, but the helper could not be started correctly. No changes were applied.</source>
        <translation>Esta operación requiere privilegios de administrador, pero el asistente no se inició correctamente. No se aplicaron cambios.</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="17"/>
        <location filename="../src/mainwindow.cpp" line="65"/>
        <source>MX Repo Manager</source>
        <translation>MX Gestor de Repositorios</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="32"/>
        <location filename="../src/mainwindow.cpp" line="881"/>
        <source>Select the APT repository that you want to use:</source>
        <translation>Seleccione el repositorio APT que desea usar:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="59"/>
        <source>MX repos</source>
        <translation>Repositorios MX</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="84"/>
        <source>Select fastest MX repo for me</source>
        <translation>Seleccionar el repositorio de MX más rápido para mí</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="110"/>
        <source>search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="168"/>
        <source>Debian repos</source>
        <translation>Repositorios Debian</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="180"/>
        <source>Select fastest Debian repo for me</source>
        <translation>Seleccionar el repositorio de Debian más rápido para mí</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="229"/>
        <source>Individual sources</source>
        <translation>Fuentes individuales</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="248"/>
        <source>Restore original APT sources</source>
        <translation>Restaurar las fuentes originales de APT</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="329"/>
        <source>Display help </source>
        <translation>Mostrar la ayuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="332"/>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="338"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="383"/>
        <source>About this application</source>
        <translation>Acerca de esta aplicación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="386"/>
        <source>About...</source>
        <translation>Acerca de...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="392"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="408"/>
        <source>Quit application</source>
        <translation>Salir de la aplicación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="411"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="417"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="436"/>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="224"/>
        <location filename="../src/mainwindow.cpp" line="677"/>
        <location filename="../src/mainwindow.cpp" line="1144"/>
        <source>Success</source>
        <translation>Exito</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="225"/>
        <location filename="../src/mainwindow.cpp" line="678"/>
        <location filename="../src/mainwindow.cpp" line="1148"/>
        <source>Your new selection will take effect the next time sources are updated.</source>
        <translation>Su nueva selección sera efectiva la próxima vez que se actualicen las fuentes.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="227"/>
        <location filename="../src/mainwindow.cpp" line="685"/>
        <source>No Changes</source>
        <translation>Sin cambios</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="228"/>
        <location filename="../src/mainwindow.cpp" line="686"/>
        <source>The selected repository is already configured.</source>
        <translation>El repositorio seleccionado ya está configurado.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="423"/>
        <source>Lists</source>
        <translation>Listas</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="423"/>
        <source>Sources (checked sources are enabled)</source>
        <translation>Fuentes (las fuentes marcadas están habilitadas)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="213"/>
        <location filename="../src/mainwindow.cpp" line="671"/>
        <location filename="../src/mainwindow.cpp" line="691"/>
        <location filename="../src/mainwindow.cpp" line="922"/>
        <location filename="../src/mainwindow.cpp" line="943"/>
        <location filename="../src/mainwindow.cpp" line="958"/>
        <location filename="../src/mainwindow.cpp" line="966"/>
        <location filename="../src/mainwindow.cpp" line="992"/>
        <location filename="../src/mainwindow.cpp" line="1005"/>
        <location filename="../src/mainwindow.cpp" line="1012"/>
        <location filename="../src/mainwindow.cpp" line="1026"/>
        <location filename="../src/mainwindow.cpp" line="1034"/>
        <location filename="../src/mainwindow.cpp" line="1090"/>
        <location filename="../src/mainwindow.cpp" line="1151"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="214"/>
        <source>Failed to update the repository sources, and some changes could not be automatically rolled back. Check %1 to restore manually.</source>
        <translation>No se pudo actualizar el repositorio y no ha sido posible revertir automáticamente algunos cambios. Consulte %1 para restaurarlos manualmente.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="217"/>
        <source>Failed to update the repository sources. Any changes made have been rolled back.</source>
        <translation>No se pudo actualizar el repositorio. Se han revertido todos los cambios realizados.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="671"/>
        <location filename="../src/mainwindow.cpp" line="691"/>
        <source>Could not change the repo.</source>
        <translation>So se pudo cambiar el repositorio.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="715"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="721"/>
        <source>Please wait...</source>
        <translation>Por favor, espere...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="795"/>
        <source>Some Changes Not Applied</source>
        <translation>Algunos cambios no se han aplicado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="796"/>
        <source>One or more repository changes could not be applied. Please check the affected sources manually.</source>
        <translation>No se pudo aplicar uno o varios cambios del repositorio. Por favor, comprueba manualmente los archivos afectados.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="805"/>
        <source>About %1</source>
        <translation>Acerca de %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="806"/>
        <source>Version: </source>
        <translation>Versión: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="808"/>
        <source>Program for choosing the default APT repository</source>
        <translation>Programa para elegir el repositorio APT predeterminado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="810"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="811"/>
        <source>%1 License</source>
        <translation>%1 Licencia</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="825"/>
        <source>%1 Help</source>
        <translation>%1 Ayuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="842"/>
        <source>Warning</source>
        <translation>Advertencia</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="843"/>
        <source>You have selected MX Test Repo. It&apos;s not recommended to leave it enabled or to upgrade all the packages from it.</source>
        <translation>Ha seleccionado MX Repositorios de Prueba. No se recomienda dejarlo habilitado o actualizar todos los paquetes.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="846"/>
        <source>A safer option is to install packages individually with MX Package Installer.</source>
        <translation>Una opción más segura es instalar paquetes individualmente con MX Instalador de Paquetes.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="883"/>
        <source>Select the APT repository and sources that you want to use:</source>
        <translation>Seleccione el repositorio APT y las fuentes que desea usar:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="943"/>
        <source>netselect-apt could not detect fastest repo.</source>
        <translation>netselect-apt no pudo detectar el repositorio más rápido.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1090"/>
        <location filename="../src/mainwindow.cpp" line="1151"/>
        <source>Could not restore the original APT source files.</source>
        <translation>No se pudo restaurar los archivos de fuentes APT originales</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="922"/>
        <location filename="../src/mainwindow.cpp" line="958"/>
        <location filename="../src/mainwindow.cpp" line="966"/>
        <location filename="../src/mainwindow.cpp" line="992"/>
        <source>Could not detect fastest repo.</source>
        <translation>No se pudo detectar el repositorio más rápido.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="75"/>
        <source>Updating package sources...</source>
        <translation>Actualizando fuentes de paquetes...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1005"/>
        <source>Can&apos;t figure out if this app is running on antiX or MX</source>
        <translation>No puedo determinar si esta aplicación se ejecuta en antiX o MX</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1013"/>
        <source>MX version not detected or out of range: </source>
        <translation>Versión de MX no detectada o fuera de rango:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1026"/>
        <source>Could not download original APT files.</source>
        <translation>No se pudieron descargar los archivos APT originales.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1034"/>
        <source>Could not unzip downloaded file.</source>
        <translation>No se pudo descomprimir el archivo descargado.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1077"/>
        <source>Enabling AHS</source>
        <translation>Habilitar AHS</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1077"/>
        <source>Do you use AHS (Advanced Hardware Stack) repo?</source>
        <translation>¿Utilizará el repo de AHS (Advanced Hardware Stack)?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1145"/>
        <source>Original APT sources have been restored to the release status. User added source files in /etc/apt/sources.list.d/ have not been touched.</source>
        <translation>Las fuentes APT originales se han restaurado al estado de liberacion. Los archivos de fuentes añadidos por el usuario en /etc/apt/sources.list.d/ no se han tocado.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="58"/>
        <source>Could not load %1</source>
        <translation>No se pudo cargar %1</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="81"/>
        <source>License</source>
        <translation>Licencia</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="82"/>
        <location filename="../src/about.cpp" line="92"/>
        <source>Changelog</source>
        <translation>Registro de cambios</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="83"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="104"/>
        <source>Could not load changelog.</source>
        <translation>No se pudo cargar el registro de cambios.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="33"/>
        <location filename="../src/about.cpp" line="107"/>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="82"/>
        <location filename="../src/main.cpp" line="91"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="83"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Parece que ha iniciado sesión como root, cierre la sesión e inicie sesión como usuario normal para usar este programa.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="92"/>
        <source>You must run this program with admin access.</source>
        <translation>Debe ejecutar este programa con acceso de administrador.</translation>
    </message>
</context>
</TS>