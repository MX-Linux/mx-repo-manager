<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="it">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="185"/>
        <source>Authentication Canceled</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="186"/>
        <source>Authentication was canceled. No changes were applied.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="188"/>
        <source>Administrator Access Required</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="189"/>
        <source>This operation requires administrator privileges, but the helper could not be started correctly. No changes were applied.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="17"/>
        <location filename="../src/mainwindow.cpp" line="65"/>
        <source>MX Repo Manager</source>
        <translation>MX Repo Manager</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="32"/>
        <location filename="../src/mainwindow.cpp" line="888"/>
        <source>Select the APT repository that you want to use:</source>
        <translation>Scegli il Repository di APT da utilizzare</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="59"/>
        <source>MX repos</source>
        <translation>MX repos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="84"/>
        <source>Select fastest MX repo for me</source>
        <translation>Seleziona l&apos;MX-repo più veloce per me </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="110"/>
        <source>search</source>
        <translation>cerca</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="168"/>
        <source>Debian repos</source>
        <translation>Debian repos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="180"/>
        <source>Select fastest Debian repo for me</source>
        <translation>Seleziona il Debian-repo più veloce per me </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="229"/>
        <source>Individual sources</source>
        <translation>Sorgenti individuali</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="248"/>
        <source>Restore original APT sources</source>
        <translation>Ripristina le sorgenti originali di APT</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="329"/>
        <source>Display help </source>
        <translation>Visualizza la guida</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="332"/>
        <source>Help</source>
        <translation>Aiuto</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="338"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="383"/>
        <source>About this application</source>
        <translation>Informazioni su questa applicazione</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="386"/>
        <source>About...</source>
        <translation>Info...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="392"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="408"/>
        <source>Quit application</source>
        <translation>Esci dall&apos;applicazione</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="411"/>
        <source>Close</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="417"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="436"/>
        <source>Apply</source>
        <translation>Applica</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="224"/>
        <location filename="../src/mainwindow.cpp" line="684"/>
        <location filename="../src/mainwindow.cpp" line="1151"/>
        <source>Success</source>
        <translation>Operazione riuscita</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="225"/>
        <location filename="../src/mainwindow.cpp" line="685"/>
        <location filename="../src/mainwindow.cpp" line="1155"/>
        <source>Your new selection will take effect the next time sources are updated.</source>
        <translation>La tua selezione avrà effetto col prossimo aggiornamento delle sorgenti dei repository.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="227"/>
        <location filename="../src/mainwindow.cpp" line="692"/>
        <source>No Changes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="228"/>
        <location filename="../src/mainwindow.cpp" line="693"/>
        <source>The selected repository is already configured.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="430"/>
        <source>Lists</source>
        <translation>Elenchi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="430"/>
        <source>Sources (checked sources are enabled)</source>
        <translation>Sorgenti (le sorgenti vidimate sono abilitate)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="213"/>
        <location filename="../src/mainwindow.cpp" line="678"/>
        <location filename="../src/mainwindow.cpp" line="698"/>
        <location filename="../src/mainwindow.cpp" line="929"/>
        <location filename="../src/mainwindow.cpp" line="950"/>
        <location filename="../src/mainwindow.cpp" line="965"/>
        <location filename="../src/mainwindow.cpp" line="973"/>
        <location filename="../src/mainwindow.cpp" line="999"/>
        <location filename="../src/mainwindow.cpp" line="1012"/>
        <location filename="../src/mainwindow.cpp" line="1019"/>
        <location filename="../src/mainwindow.cpp" line="1033"/>
        <location filename="../src/mainwindow.cpp" line="1041"/>
        <location filename="../src/mainwindow.cpp" line="1097"/>
        <location filename="../src/mainwindow.cpp" line="1158"/>
        <source>Error</source>
        <translation>Errore</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="214"/>
        <source>Failed to update the repository sources, and some changes could not be automatically rolled back. Check %1 to restore manually.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="217"/>
        <source>Failed to update the repository sources. Any changes made have been rolled back.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="678"/>
        <location filename="../src/mainwindow.cpp" line="698"/>
        <source>Could not change the repo.</source>
        <translation>Repository non modificabile</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="722"/>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="728"/>
        <source>Please wait...</source>
        <translation>Attendi...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="802"/>
        <source>Some Changes Not Applied</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="803"/>
        <source>One or more repository changes could not be applied. Please check the affected sources manually.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="812"/>
        <source>About %1</source>
        <translation>Circa %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="813"/>
        <source>Version: </source>
        <translation>Versione: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="815"/>
        <source>Program for choosing the default APT repository</source>
        <translation>Programma per selezionare il Repository di APT predefinito</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="817"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="818"/>
        <source>%1 License</source>
        <translation>%1 Licenza</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="832"/>
        <source>%1 Help</source>
        <translation>%1 Aiuto</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="849"/>
        <source>Warning</source>
        <translation>Attenzione</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="850"/>
        <source>You have selected MX Test Repo. It&apos;s not recommended to leave it enabled or to upgrade all the packages from it.</source>
        <translation>Hai selezionato MX Test Repo. Si raccomanda di non lasciarlo abilitato o almeno di non lasciarlo abilitato quando si aggiornano tutti i pacchetti.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="853"/>
        <source>A safer option is to install packages individually with MX Package Installer.</source>
        <translation>Un&apos;opzione più sicura è installare i pacchetti individualmente con MX Installa Programmi.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="890"/>
        <source>Select the APT repository and sources that you want to use:</source>
        <translation>Seleziona il repository di APT e i sorgenti che vuoi usare:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="950"/>
        <source>netselect-apt could not detect fastest repo.</source>
        <translation>netselect-apt non riesce a rilevare il repo più veloce.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1097"/>
        <location filename="../src/mainwindow.cpp" line="1158"/>
        <source>Could not restore the original APT source files.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="929"/>
        <location filename="../src/mainwindow.cpp" line="965"/>
        <location filename="../src/mainwindow.cpp" line="973"/>
        <location filename="../src/mainwindow.cpp" line="999"/>
        <source>Could not detect fastest repo.</source>
        <translation>Non si riesce a rilevare il repo più veloce.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="75"/>
        <source>Updating package sources...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1012"/>
        <source>Can&apos;t figure out if this app is running on antiX or MX</source>
        <translation>Impossibile stabilire se questa applicazione sia in esecuzione su antiX o MX</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1020"/>
        <source>MX version not detected or out of range: </source>
        <translation>Versione di MX non rilevata o fuori numerazione:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1033"/>
        <source>Could not download original APT files.</source>
        <translation>Non si riesce a scaricare i file di APT originali.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1041"/>
        <source>Could not unzip downloaded file.</source>
        <translation>Impossibile scomprimere il file scaricato.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1084"/>
        <source>Enabling AHS</source>
        <translation>Abilitazione di AHS</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1084"/>
        <source>Do you use AHS (Advanced Hardware Stack) repo?</source>
        <translation>Usi il repo AHS (Advanced Hardware Stack)?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1152"/>
        <source>Original APT sources have been restored to the release status. User added source files in /etc/apt/sources.list.d/ have not been touched.</source>
        <translation>Le sorgenti di APT originali sono state ripristinate a quelle previste per l&apos;attuale release. I file delle sorgenti, aggiunte dall&apos;utente in /etc/apt/sources.list.d/, non sono stati toccati.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="58"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="81"/>
        <source>License</source>
        <translation>Licenza</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="82"/>
        <location filename="../src/about.cpp" line="92"/>
        <source>Changelog</source>
        <translation>Registro delle modifiche</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="83"/>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="104"/>
        <source>Could not load changelog.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="33"/>
        <location filename="../src/about.cpp" line="107"/>
        <source>&amp;Close</source>
        <translation>&amp;Chiudi</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="82"/>
        <location filename="../src/main.cpp" line="91"/>
        <source>Error</source>
        <translation>Errore</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="83"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Sembra che tu sia loggato come root, fai il log out e poi il log in come utente normale per usare questo programma.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="92"/>
        <source>You must run this program with admin access.</source>
        <translation>Devi eseguire questo programma come amministratore.</translation>
    </message>
</context>
</TS>